<?php

//CRUD
class tarefaService {
    public function inserir(){ //CREATE

    }
    public function recuperar(){ //READ

    }
    public function atualizar(){ //UPDATE

    }
    public function remover(){ //DELETE

    }
}


?>